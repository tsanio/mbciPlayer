var searchData=
[
  ['rebootmindwave',['reBootMindWave',['../db/d13/namespaceplr_common.html#a5fa99301938bc03a916e2350c693ba5c',1,'plrCommon']]],
  ['rebootopeneeg',['reBootOpenEEG',['../db/d13/namespaceplr_common.html#aa141333c2886b97aee127e1cc1231caa',1,'plrCommon']]],
  ['recordbrainwavebox',['recordBrainWaveBox',['../db/d13/namespaceplr_common.html#aedb33cb31d1b3f00bfc92f4ecd43e863',1,'plrCommon']]],
  ['recordmodebutton',['RecordModeButton',['../db/d13/namespaceplr_common.html#a798e20d40b9262407fce6926e75f4794',1,'plrCommon']]],
  ['resultsfilename',['resultsFileName',['../db/d13/namespaceplr_common.html#ad96033de425639a3aae0f0116b66075b',1,'plrCommon']]],
  ['resultsfilename2',['resultsFileName2',['../db/d13/namespaceplr_common.html#a6f2de1824c3eef8f72cd3f7dfed906d8',1,'plrCommon']]]
];
