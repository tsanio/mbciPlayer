var searchData=
[
  ['plrcommon',['plrCommon',['../db/d13/namespaceplr_common.html',1,'']]]
];
