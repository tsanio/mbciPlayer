var searchData=
[
  ['howmanychannelsinopeneeg',['howManyChannelsInOpenEEG',['../db/d13/namespaceplr_common.html#aa4e63047781e7c424a9f62fdc0f015d4',1,'plrCommon']]]
];
