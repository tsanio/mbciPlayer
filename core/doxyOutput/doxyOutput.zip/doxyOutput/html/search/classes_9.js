var searchData=
[
  ['resultpair',['ResultPair',['../dc/d87/class_result_pair.html',1,'']]]
];
