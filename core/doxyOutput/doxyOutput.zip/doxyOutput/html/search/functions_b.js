var searchData=
[
  ['unloadfonts',['unLoadFonts',['../db/d13/namespaceplr_common.html#a7abde416c97852a8573ba56db29f2d22',1,'plrCommon']]],
  ['updateprofilevalues',['updateProfileValues',['../d8/d20/class_b_w_meter.html#a7e2b7b0d8ede89422ffe0cf35c01171d',1,'BWMeter']]],
  ['usingmindwave',['usingMindWave',['../db/d13/namespaceplr_common.html#a530f9ac71e22485bee26cc6f9f46cd56',1,'plrCommon']]],
  ['usingopeneeg',['usingOpenEEG',['../db/d13/namespaceplr_common.html#ac4075358b588b5825998b5ac2f6ee842',1,'plrCommon']]]
];
