var searchData=
[
  ['readpacketstream',['readPacketStream',['../db/dbb/class_open_e_e_g_device.html#a4e0f128bda0279b91dcf4e6f30b6971b',1,'OpenEEGDevice']]],
  ['removechars',['removeChars',['../db/d13/namespaceplr_common.html#a74a22393349dbb859562144267fc3826',1,'plrCommon']]],
  ['removedoubleemptyspaces',['removeDoubleEmptySpaces',['../db/d13/namespaceplr_common.html#a78b6d5923187335b9f3226638e7735ca',1,'plrCommon']]],
  ['removeexcessfrommiddle',['removeExcessFromMiddle',['../db/d13/namespaceplr_common.html#ac6343dff131c9935efd048e157dc174b',1,'plrCommon']]]
];
