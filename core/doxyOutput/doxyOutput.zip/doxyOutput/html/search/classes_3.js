var searchData=
[
  ['eegspectrumchannel',['EEGSpectrumChannel',['../da/d29/class_e_e_g_spectrum_channel.html',1,'']]]
];
