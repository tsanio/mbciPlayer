var searchData=
[
  ['amount_5fof_5fpeaks_5fin_5fchannel',['AMOUNT_OF_PEAKS_IN_CHANNEL',['../db/d13/namespaceplr_common.html#ad39ddba809648074ba6a2391cad3fa8d',1,'plrCommon']]],
  ['angleroutines',['AngleRoutines',['../d6/d02/class_angle_routines.html',1,'']]]
];
