var searchData=
[
  ['openeegdevice',['OpenEEGDevice',['../db/dbb/class_open_e_e_g_device.html',1,'']]]
];
