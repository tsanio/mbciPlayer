var searchData=
[
  ['getdistance',['getDistance',['../db/d13/namespaceplr_common.html#a829710cf99a7b22b90df4f7ba3194adc',1,'plrCommon']]],
  ['getdistancebetweenvalues',['getDistanceBetweenValues',['../db/d13/namespaceplr_common.html#a87681a7fd99f6e26689a28a50478107b',1,'plrCommon']]],
  ['getfromcolortocolor',['getFromColorToColor',['../db/d13/namespaceplr_common.html#a27c51d643ab796b115ff63007f15d4df',1,'plrCommon']]],
  ['getmapcolor',['getMapColor',['../db/d13/namespaceplr_common.html#ae0abc0b6e1b2f14be0ec79e3f78d2f08',1,'plrCommon']]],
  ['getnegationofthisprefix',['getNegationOfThisPrefix',['../db/d13/namespaceplr_common.html#ae13e87184a87bb40a1d96ad6c4b3c30b',1,'plrCommon']]],
  ['getpositiveofthis',['getPositiveOfThis',['../db/d13/namespaceplr_common.html#a7a6d1670440159feb1bdb1f5c775692e',1,'plrCommon']]],
  ['getprefixof',['getPrefixOf',['../db/d13/namespaceplr_common.html#a43846d8d11379d5d5b51c0094ff40de3',1,'plrCommon']]],
  ['getrawchannelvalueoftimepoint',['getRawChannelValueOfTimePoint',['../db/dbb/class_open_e_e_g_device.html#a36cc936fb013b3f0acd7e2a808cbb562',1,'OpenEEGDevice']]],
  ['getrawscaledvalue',['getRawScaledValue',['../db/dbb/class_open_e_e_g_device.html#a7c4a007ebc30791cfefff96172bbd9a1',1,'OpenEEGDevice']]],
  ['getscaledimage',['getScaledImage',['../db/d13/namespaceplr_common.html#ac697a7b68db48641a431d32571c3eaad',1,'plrCommon']]],
  ['gettimestamp',['getTimeStamp',['../db/d13/namespaceplr_common.html#aca5c9fd4e26d0d8ea9d66a61dc92765d',1,'plrCommon']]],
  ['getvalueinsideboundaries',['getValueInsideBoundaries',['../db/d13/namespaceplr_common.html#a2f8dd9d960698f0a64317cbc9c84b583',1,'plrCommon']]]
];
