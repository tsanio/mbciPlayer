var searchData=
[
  ['readpacketstream',['readPacketStream',['../db/dbb/class_open_e_e_g_device.html#a4e0f128bda0279b91dcf4e6f30b6971b',1,'OpenEEGDevice']]],
  ['rebootmindwave',['reBootMindWave',['../db/d13/namespaceplr_common.html#a5fa99301938bc03a916e2350c693ba5c',1,'plrCommon']]],
  ['rebootopeneeg',['reBootOpenEEG',['../db/d13/namespaceplr_common.html#aa141333c2886b97aee127e1cc1231caa',1,'plrCommon']]],
  ['recordbrainwavebox',['recordBrainWaveBox',['../db/d13/namespaceplr_common.html#aedb33cb31d1b3f00bfc92f4ecd43e863',1,'plrCommon']]],
  ['recordmodebutton',['RecordModeButton',['../db/d13/namespaceplr_common.html#a798e20d40b9262407fce6926e75f4794',1,'plrCommon']]],
  ['removechars',['removeChars',['../db/d13/namespaceplr_common.html#a74a22393349dbb859562144267fc3826',1,'plrCommon']]],
  ['removedoubleemptyspaces',['removeDoubleEmptySpaces',['../db/d13/namespaceplr_common.html#a78b6d5923187335b9f3226638e7735ca',1,'plrCommon']]],
  ['removeexcessfrommiddle',['removeExcessFromMiddle',['../db/d13/namespaceplr_common.html#ac6343dff131c9935efd048e157dc174b',1,'plrCommon']]],
  ['resultpair',['ResultPair',['../dc/d87/class_result_pair.html',1,'']]],
  ['resultsfilename',['resultsFileName',['../db/d13/namespaceplr_common.html#ad96033de425639a3aae0f0116b66075b',1,'plrCommon']]],
  ['resultsfilename2',['resultsFileName2',['../db/d13/namespaceplr_common.html#a6f2de1824c3eef8f72cd3f7dfed906d8',1,'plrCommon']]]
];
